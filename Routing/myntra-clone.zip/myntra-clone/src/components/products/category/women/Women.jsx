import React from 'react'

const Women = () => {
  return (
    <div>Women</div>
  )
}

export default Women