import React from 'react'

const RightSideHeader = () => {
  return (
    <div className='RightSideBar'>RightSideHeader</div>
  )
}

export default RightSideHeader