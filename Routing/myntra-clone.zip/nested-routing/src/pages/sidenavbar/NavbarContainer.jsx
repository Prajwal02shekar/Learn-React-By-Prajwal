import React from 'react'
import Menu from './Menu'

const NavbarContainer = () => {
  return (
    <>
    <Menu/>    
    </>
  )
}

export default NavbarContainer